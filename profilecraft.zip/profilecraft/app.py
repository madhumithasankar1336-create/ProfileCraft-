"""ProfileCraft - Flask backend (REST API, SQLite storage, secure image uploads)."""
import io
import json
import os
import re
import sqlite3
import uuid
from collections import Counter
from datetime import datetime, timezone
from urllib.parse import urlparse

from flask import Flask, g, jsonify, render_template, request
from flask_cors import CORS
from PIL import Image, UnidentifiedImageError
from werkzeug.exceptions import HTTPException

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get("PROFILECRAFT_DB", os.path.join(BASE_DIR, "profilecraft.db"))
UPLOAD_DIR = os.path.join(BASE_DIR, "static", "uploads")

ALLOWED_IMAGE_EXT = {"png", "jpg", "jpeg", "gif", "webp"}
ALLOWED_IMAGE_FORMATS = {"PNG", "JPEG", "GIF", "WEBP"}
MAX_IMAGE_BYTES = 2 * 1024 * 1024
THEMES = ("modern", "professional", "minimal", "gradient", "glassmorphism")
TEMPLATE_COUNT = 5
SOCIAL_KEYS = ("linkedin", "github", "instagram", "portfolio")
TEXT_LIMITS = {
    "full_name": (2, 80),
    "username": (3, 30),
    "email": (5, 120),
    "bio": (0, 500),
    "location": (0, 80),
    "title": (0, 80),
    "image_url": (0, 500),
}
REQUIRED = {"full_name", "username", "email"}
USERNAME_RE = re.compile(r"^[A-Za-z0-9_]{3,30}$")
EMAIL_RE = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]+$")

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = MAX_IMAGE_BYTES + 256 * 1024
CORS(app)
os.makedirs(UPLOAD_DIR, exist_ok=True)


class ApiError(Exception):
    """Expected, client-facing error that renders as JSON."""

    def __init__(self, message, status=400, errors=None):
        super().__init__(message)
        self.message = message
        self.status = status
        self.errors = errors or {}


# ---------------------------------------------------------------- database
SCHEMA = """
CREATE TABLE IF NOT EXISTS profiles (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    full_name   TEXT NOT NULL,
    username    TEXT NOT NULL UNIQUE COLLATE NOCASE,
    email       TEXT NOT NULL,
    bio         TEXT DEFAULT '',
    location    TEXT DEFAULT '',
    title       TEXT DEFAULT '',
    image_url   TEXT DEFAULT '',
    image_file  TEXT DEFAULT '',
    skills      TEXT DEFAULT '[]',
    interests   TEXT DEFAULT '[]',
    social      TEXT DEFAULT '{}',
    theme       TEXT DEFAULT 'modern',
    template    INTEGER DEFAULT 1,
    is_favorite INTEGER DEFAULT 0,
    created_at  TEXT NOT NULL,
    updated_at  TEXT NOT NULL
);
"""


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(_exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    conn = sqlite3.connect(DB_PATH)
    try:
        conn.executescript(SCHEMA)
        conn.commit()
    finally:
        conn.close()


init_db()


# ---------------------------------------------------------------- helpers
def now_iso():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def as_list(value):
    """Accept a list, a JSON array string, or a comma-separated string."""
    if value in (None, ""):
        return []
    if isinstance(value, list):
        return value
    if isinstance(value, str):
        try:
            parsed = json.loads(value)
            if isinstance(parsed, list):
                return parsed
        except json.JSONDecodeError:
            pass
        return [part for part in value.split(",")]
    return []


def as_dict(value):
    if isinstance(value, dict):
        return value
    if isinstance(value, str) and value.strip():
        try:
            parsed = json.loads(value)
            return parsed if isinstance(parsed, dict) else {}
        except json.JSONDecodeError:
            return {}
    return {}


def is_valid_url(value):
    if not value:
        return True
    try:
        parsed = urlparse(value)
    except ValueError:
        return False
    return parsed.scheme in ("http", "https") and bool(parsed.netloc)


def clean_tags(items, label, errors):
    result, seen = [], set()
    for item in items:
        tag = str(item).strip()
        if not tag:
            continue
        if len(tag) > 30:
            errors[label] = "Each skill or interest must be 30 characters or fewer"
            return result
        if tag.lower() in seen:
            continue
        seen.add(tag.lower())
        result.append(tag)
    if len(result) > 30:
        errors[label] = "Maximum 30 items allowed"
        result = result[:30]
    return result


def completion_of(p):
    checks = [
        bool(p.get("full_name")),
        bool(p.get("username")),
        bool(p.get("email")),
        bool(p.get("bio")),
        bool(p.get("location")),
        bool(p.get("title")),
        bool(p.get("image")),
        bool(p.get("skills")),
        bool(p.get("interests")),
        any((p.get("social") or {}).values()),
    ]
    return round(sum(checks) / len(checks) * 100)


def row_to_profile(row):
    p = dict(row)
    p["skills"] = json.loads(p.get("skills") or "[]")
    p["interests"] = json.loads(p.get("interests") or "[]")
    p["social"] = json.loads(p.get("social") or "{}")
    p["is_favorite"] = bool(p.get("is_favorite"))
    p["image"] = f"/static/uploads/{p['image_file']}" if p.get("image_file") else (p.get("image_url") or "")
    p["completion"] = completion_of(p)
    return p


def fetch_or_404(pid):
    row = get_db().execute("SELECT * FROM profiles WHERE id = ?", (pid,)).fetchone()
    if row is None:
        raise ApiError("Profile not found", 404)
    return row


def read_payload():
    """Return (fields, uploaded_file). Supports JSON and multipart/form-data."""
    if request.is_json:
        data = request.get_json(silent=True)
        if not isinstance(data, dict):
            raise ApiError("Request body must be a JSON object", 400)
        return data, None
    return request.form.to_dict(), request.files.get("image")


def clean_profile(data, base, pid=None):
    """Validate and normalise input. Missing keys fall back to `base` (for PUT)."""
    errors = {}

    def pick(key, default=""):
        if key in data:
            return data[key]
        return base.get(key, default)

    def text(key):
        value = str(pick(key) or "").strip()
        lo, hi = TEXT_LIMITS[key]
        if not value:
            if key in REQUIRED:
                errors[key] = "This field is required"
        elif len(value) > hi:
            errors[key] = f"Must be at most {hi} characters"
        elif len(value) < lo:
            errors[key] = f"Must be at least {lo} characters"
        return value

    out = {}
    out["full_name"] = text("full_name")

    username = str(pick("username") or "").strip()
    if not username:
        errors["username"] = "This field is required"
    elif not USERNAME_RE.match(username):
        errors["username"] = "Use 3-30 letters, numbers or underscores"
    else:
        dup = get_db().execute(
            "SELECT id FROM profiles WHERE username = ? COLLATE NOCASE AND id IS NOT ?",
            (username, pid),
        ).fetchone()
        if dup:
            errors["username"] = "Username is already taken"
    out["username"] = username

    email = text("email")
    if email and not EMAIL_RE.match(email):
        errors["email"] = "Enter a valid email address"
    out["email"] = email

    out["bio"] = text("bio")
    out["location"] = text("location")
    out["title"] = text("title")

    image_url = str(pick("image_url") or "").strip()
    if not is_valid_url(image_url):
        errors["image_url"] = "Enter a valid http(s) URL"
    out["image_url"] = image_url

    social_in = as_dict(pick("social", {}))
    social = {}
    for key in SOCIAL_KEYS:
        value = str(social_in.get(key) or "").strip()
        if value and not is_valid_url(value):
            errors[key] = "Enter a valid http(s) URL"
        social[key] = value
    out["social"] = social

    out["skills"] = clean_tags(as_list(pick("skills", [])), "skills", errors)
    out["interests"] = clean_tags(as_list(pick("interests", [])), "interests", errors)

    theme = str(pick("theme", "modern") or "modern").lower()
    out["theme"] = theme if theme in THEMES else "modern"

    try:
        template = int(pick("template", 1))
    except (TypeError, ValueError):
        template = 1
    out["template"] = template if 1 <= template <= TEMPLATE_COUNT else 1

    return out, errors


def save_upload(file_storage):
    """Validate an uploaded image, re-encode it (strips metadata) and store it."""
    filename = file_storage.filename or ""
    ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
    if ext not in ALLOWED_IMAGE_EXT:
        raise ApiError("Unsupported image type", 400, {"image": "Use PNG, JPG, GIF or WEBP"})

    data = file_storage.read(MAX_IMAGE_BYTES + 1)
    if len(data) > MAX_IMAGE_BYTES:
        raise ApiError("Image too large", 413, {"image": "Maximum size is 2 MB"})

    try:
        Image.open(io.BytesIO(data)).verify()          # integrity check
        img = Image.open(io.BytesIO(data))             # reopen; verify() invalidates the object
    except (UnidentifiedImageError, OSError, SyntaxError):
        raise ApiError("Invalid image file", 400, {"image": "File is not a valid image"})

    if (img.format or "").upper() not in ALLOWED_IMAGE_FORMATS:
        raise ApiError("Unsupported image format", 400, {"image": "Use PNG, JPG, GIF or WEBP"})

    img.thumbnail((800, 800))
    has_alpha = img.mode in ("RGBA", "LA") or "transparency" in img.info
    name_stub = uuid.uuid4().hex
    if has_alpha:
        out = img.convert("RGBA")
        name = f"{name_stub}.png"
        out.save(os.path.join(UPLOAD_DIR, name), "PNG", optimize=True)
    else:
        out = img.convert("RGB")
        name = f"{name_stub}.jpg"
        out.save(os.path.join(UPLOAD_DIR, name), "JPEG", quality=90)
    return name


def remove_upload(name):
    if not name:
        return
    safe = os.path.basename(name)
    path = os.path.join(UPLOAD_DIR, safe)
    if os.path.isfile(path):
        try:
            os.remove(path)
        except OSError:
            app.logger.warning("Could not delete upload %s", safe)


# ---------------------------------------------------------------- pages
@app.route("/")
@app.route("/p/<int:pid>")          # shareable link: opens the profile in the UI
def index(pid=None):
    return render_template("index.html")


# ---------------------------------------------------------------- API
@app.route("/api/profiles", methods=["GET"])
def list_profiles():
    q = (request.args.get("q") or "").strip().lower()
    favorites_only = request.args.get("favorites") == "1"
    rows = get_db().execute("SELECT * FROM profiles ORDER BY created_at DESC, id DESC").fetchall()
    profiles = [row_to_profile(r) for r in rows]
    if favorites_only:
        profiles = [p for p in profiles if p["is_favorite"]]
    if q:
        profiles = [
            p for p in profiles
            if q in " ".join([
                p["full_name"], p["username"], p["title"], p["location"],
                " ".join(p["skills"]), " ".join(p["interests"]),
            ]).lower()
        ]
    return jsonify(success=True, count=len(profiles), data=profiles)


@app.route("/api/profiles", methods=["POST"])
def create_profile():
    data, upload = read_payload()
    profile, errors = clean_profile(data, {}, None)
    if errors:
        raise ApiError("Validation failed", 422, errors)

    image_file = save_upload(upload) if upload and upload.filename else ""
    ts = now_iso()
    db = get_db()
    try:
        cur = db.execute(
            """INSERT INTO profiles (full_name, username, email, bio, location, title, image_url,
                   image_file, skills, interests, social, theme, template, is_favorite, created_at, updated_at)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,0,?,?)""",
            (
                profile["full_name"], profile["username"], profile["email"], profile["bio"],
                profile["location"], profile["title"], profile["image_url"], image_file,
                json.dumps(profile["skills"]), json.dumps(profile["interests"]),
                json.dumps(profile["social"]), profile["theme"], profile["template"], ts, ts,
            ),
        )
        db.commit()
    except sqlite3.IntegrityError:
        remove_upload(image_file)
        raise ApiError("Username is already taken", 409, {"username": "Username is already taken"})

    row = fetch_or_404(cur.lastrowid)
    return jsonify(success=True, message="Profile created", data=row_to_profile(row)), 201


@app.route("/api/profiles/<int:pid>", methods=["GET"])
def get_profile(pid):
    return jsonify(success=True, data=row_to_profile(fetch_or_404(pid)))


@app.route("/api/profiles/<int:pid>", methods=["PUT", "PATCH"])
def update_profile(pid):
    existing_row = fetch_or_404(pid)
    existing = row_to_profile(existing_row)
    data, upload = read_payload()
    profile, errors = clean_profile(data, existing, pid)
    if errors:
        raise ApiError("Validation failed", 422, errors)

    image_file = existing_row["image_file"] or ""
    remove_flag = str(data.get("remove_image", "")).lower() in ("1", "true", "yes")
    if upload and upload.filename:
        new_file = save_upload(upload)
        remove_upload(image_file)
        image_file = new_file
    elif remove_flag:
        remove_upload(image_file)
        image_file = ""

    db = get_db()
    db.execute(
        """UPDATE profiles SET full_name=?, username=?, email=?, bio=?, location=?, title=?,
               image_url=?, image_file=?, skills=?, interests=?, social=?, theme=?, template=?, updated_at=?
           WHERE id=?""",
        (
            profile["full_name"], profile["username"], profile["email"], profile["bio"],
            profile["location"], profile["title"], profile["image_url"], image_file,
            json.dumps(profile["skills"]), json.dumps(profile["interests"]),
            json.dumps(profile["social"]), profile["theme"], profile["template"], now_iso(), pid,
        ),
    )
    db.commit()
    return jsonify(success=True, message="Profile updated", data=row_to_profile(fetch_or_404(pid)))


@app.route("/api/profiles/<int:pid>", methods=["DELETE"])
def delete_profile(pid):
    row = fetch_or_404(pid)
    db = get_db()
    db.execute("DELETE FROM profiles WHERE id = ?", (pid,))
    db.commit()
    remove_upload(row["image_file"])
    return jsonify(success=True, message="Profile deleted", id=pid)


@app.route("/api/profiles/<int:pid>/favorite", methods=["POST"])
def toggle_favorite(pid):
    row = fetch_or_404(pid)
    new_value = 0 if row["is_favorite"] else 1
    db = get_db()
    db.execute("UPDATE profiles SET is_favorite = ? WHERE id = ?", (new_value, pid))
    db.commit()
    message = "Added to favorites" if new_value else "Removed from favorites"
    return jsonify(success=True, message=message, data=row_to_profile(fetch_or_404(pid)))


@app.route("/api/stats", methods=["GET"])
def stats():
    rows = get_db().execute("SELECT * FROM profiles ORDER BY created_at DESC, id DESC").fetchall()
    profiles = [row_to_profile(r) for r in rows]
    counter = Counter(s.lower() for p in profiles for s in p["skills"])
    avg = round(sum(p["completion"] for p in profiles) / len(profiles)) if profiles else 0
    recent = [
        {
            "id": p["id"], "full_name": p["full_name"], "username": p["username"],
            "title": p["title"], "image": p["image"], "completion": p["completion"],
            "is_favorite": p["is_favorite"],
        }
        for p in profiles[:5]
    ]
    return jsonify(
        success=True,
        data={
            "total": len(profiles),
            "favorites": sum(1 for p in profiles if p["is_favorite"]),
            "unique_skills": len(counter),
            "avg_completion": avg,
            "top_skills": [{"name": n, "count": c} for n, c in counter.most_common(6)],
            "recent": recent,
        },
    )


@app.route("/api/health", methods=["GET"])
def health():
    return jsonify(success=True, status="ok")


# ---------------------------------------------------------------- errors
@app.errorhandler(ApiError)
def handle_api_error(err):
    return jsonify(success=False, message=err.message, errors=err.errors), err.status


@app.errorhandler(413)
def handle_too_large(_err):
    return jsonify(success=False, message="Image too large. Maximum size is 2 MB.",
                   errors={"image": "Maximum size is 2 MB"}), 413


@app.errorhandler(Exception)
def handle_unexpected(err):
    if isinstance(err, HTTPException):
        if request.path.startswith("/api/"):
            return jsonify(success=False, message=err.description or err.name), err.code
        return err
    app.logger.exception("Unhandled error")
    return jsonify(success=False, message="Internal server error"), 500


if __name__ == "__main__":
    app.run(debug=True, port=5000)

# ProfileCraft - Smart User Profile Card Generator

A full-stack digital identity platform: create, customise, manage, download and share
profile cards.

- **Backend:** Python Flask, REST JSON API, SQLite, Pillow image processing, Flask-CORS
- **Frontend:** HTML5, CSS3, vanilla JavaScript (no build step)
- **Background:** GhostFibers - a dependency-free WebGL2 port of the React component

## Features

| Area | What's included |
|---|---|
| Profile form | Name, username, email, bio, title, location, image upload or URL, skills and interests tag managers, LinkedIn / GitHub / Instagram / Portfolio links |
| Live preview | Card updates on every keystroke with a completion indicator |
| Themes | Modern, Professional, Minimal, Gradient, Glassmorphism |
| Templates | 5 layouts: Classic, Banner, Split, Compact, Spotlight |
| CRUD | Create (POST), list (GET), get by ID (GET), edit (PUT), delete (DELETE) |
| Favorites | Toggle favorite, filter favorites |
| Search | Live search by name, username, title, location, skills or interests |
| Export | Download any card as PNG (html2canvas) |
| QR codes | Scan-to-open QR for every saved profile, downloadable |
| Sharing | Shareable `/p/<id>` links, copy-link button, native share sheet when available |
| Validation | Client-side and server-side, with inline field errors |
| UX | Toast notifications, confirm-delete modal, empty states, skeleton loaders, dark/light mode, responsive navbar |
| Dashboard | Animated stats (total, favorites, unique skills, average completion), recent profiles, top skills |

## Project structure

```
profilecraft/
├── app.py                    # Flask app: routes, validation, uploads, SQLite
├── requirements.txt
├── README.md
├── templates/
│   └── index.html            # Single-page dashboard
└── static/
    ├── css/style.css         # Glassmorphism, themes, templates, responsive layout
    ├── js/ghost-fibers.js    # WebGL2 animated background
    ├── js/app.js             # UI logic, fetch calls, rendering, events
    └── uploads/              # Uploaded images (created automatically)
```

## Setup

Requires Python 3.10+.

```bash
cd profilecraft
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

Open http://127.0.0.1:5000

The SQLite database (`profilecraft.db`) is created automatically on first run.
To use a different location, set `PROFILECRAFT_DB=/path/to/file.db` before starting.

> The page loads Font Awesome, Google Fonts, html2canvas and qrcode from public CDNs,
> so an internet connection is needed for icons, fonts, PNG export and QR codes.

## REST API

All responses are JSON in the form `{"success": bool, ...}`. Errors include `message`
and, for validation failures, an `errors` object keyed by field name.

| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/profiles` | Create a profile (multipart form or JSON). Returns `201`. |
| GET | `/api/profiles` | List profiles. Query params: `q` (search), `favorites=1` |
| GET | `/api/profiles/<id>` | Get one profile |
| PUT | `/api/profiles/<id>` | Update a profile (fields not sent keep their current value) |
| DELETE | `/api/profiles/<id>` | Delete a profile and its uploaded image |
| POST | `/api/profiles/<id>/favorite` | Toggle favorite |
| GET | `/api/stats` | Dashboard statistics |
| GET | `/api/health` | Health check |
| GET | `/p/<id>` | Shareable page that opens the profile |

### Example: create a profile with curl

```bash
curl -X POST http://127.0.0.1:5000/api/profiles \
  -F full_name="Ada Lovelace" \
  -F username=ada_lovelace \
  -F email=ada@example.com \
  -F title="Software Engineer" \
  -F skills='["Python","Flask"]' \
  -F social='{"github":"https://github.com/ada"}' \
  -F image=@photo.jpg
```

Or as JSON (no image upload):

```bash
curl -X POST http://127.0.0.1:5000/api/profiles \
  -H "Content-Type: application/json" \
  -d '{"full_name":"Ada Lovelace","username":"ada_lovelace","email":"ada@example.com","skills":["Python"]}'
```

### Image upload rules

- Allowed types: PNG, JPG, JPEG, GIF, WEBP
- Maximum size: 2 MB
- Each file is verified with Pillow, so renamed non-image files are rejected
- Images are re-encoded (resized to 800 px max, metadata stripped) and stored with random
  UUID filenames, so user-supplied filenames never touch the disk

## Testing checklist

1. Create a profile with and without an uploaded image; confirm the live preview matches the saved card.
2. Submit an empty form and confirm inline errors appear and nothing is sent.
3. Try a duplicate username and confirm the "already taken" error.
4. Edit a profile (PUT), change a theme and template, and confirm the grid updates.
5. Toggle favorite and use the "Favorites only" filter.
6. Search by a name and by a skill.
7. Download a PNG, open the QR modal and download the QR.
8. Copy a share link and open it in a new tab (`/p/<id>`).
9. Delete a profile and confirm the modal; check that the uploaded file is removed from `static/uploads/`.
10. Toggle dark/light mode and resize the window to check the mobile menu.

## Notes

- Share links point to the app's own origin. For a public deployment, serve the app
  behind HTTPS and run it with a production WSGI server such as gunicorn.
- For production, set `debug=False` in `app.py` (the default `__main__` block runs in debug mode).

/*
 * GhostFibers - dependency-free WebGL2 background for ProfileCraft.
 *
 * Vanilla JavaScript port of the React <GhostFibers /> component. Renders
 * instanced "bead" fibers along twisting ribbons, drifting dust, depth-of-field
 * bokeh, a bloom pass and film grain. Falls back gracefully without WebGL2.
 *
 *   const fx = GhostFibers.mount(containerEl, { glowColor: '#8b5cf6' });
 *   fx.destroy();
 */
(function (global) {
  'use strict';

  const DEG = Math.PI / 180;
  const CAMERA = 7.5;
  const FOV = 0.56;
  const RIBBON_LENGTH = 24;
  const INTRO_SECONDS = 2.6;
  const MAX_DIM = 2400;
  const FOCAL = 1 / (2 * Math.tan(FOV / 2));
  const PLACEMENTS = [
    [0, 0, 0, 0],
    [1.9, -4.6, -0.08, 2.4],
    [-1.05, 2.0, 0.12, 4.1]
  ];
  const RIBBON_GAIN = [1, 0.5, 0.55];
  const RIBBON_TINT = [0, 0.75, 0.35];
  const GRADIENTS = { depth: 0, along: 1, across: 2 };

  const DEFAULTS = {
    glowColor: '#8b5cf6',
    lineColor: '#dfd1fc',
    secondaryColor: '#6f4ac5',
    gradient: 'depth',
    speed: 0.5,
    scale: 1,
    rotation: 18,
    rollSpeed: 0.15,
    layers: 3,
    waves: 1,
    twist: 1.2,
    threads: 72,
    volume: 0.7,
    spread: 1,
    density: 1,
    thickness: 1,
    flow: 0.4,
    foldGlow: 1,
    perspective: 0.65,
    depthOfField: 0.85,
    particles: 0.5,
    sparkle: 0.5,
    glow: 0.8,
    brightness: 1,
    vignette: 0.3,
    grain: 0.06,
    intro: true,
    mouseInteraction: true
  };

  const HEADER = '#version 300 es\nprecision highp float;\n';

  // Ribbon geometry shared by the fiber and dust shaders.
  const SHAPE = `
uniform float uTime;
uniform float uTwist;
uniform float uRoll;
uniform float uWaves;
uniform float uWidth;
uniform float uRibbon;
uniform mat3 uOrient;
uniform float uScale;
uniform vec4 uPlace;
uniform float uVolume;

float hash11(float n) { return fract(sin(n * 91.3458) * 47453.5453); }

vec3 centerLocal(float s) {
  float t = uTime;
  float ph = uPlace.w;
  float x = s * ${RIBBON_LENGTH.toFixed(1)};
  float y = uWaves * (0.52 * sin(x * 0.43 + t * 0.31 + ph) + 0.26 * sin(x * 0.79 - t * 0.23 + 1.3 + ph * 0.7)) + uPlace.x + x * uPlace.z;
  float z = uWaves * 0.65 * sin(x * 0.33 + t * 0.19 + 0.7 + ph * 1.3) + uPlace.y;
  return vec3(x, y, z);
}

float twistAt(float s, float layer) {
  float x = s * ${RIBBON_LENGTH.toFixed(1)};
  return uTwist * 0.483 * x + uRoll + uPlace.w * 0.6 + layer * uVolume * 0.42 + 0.5 * sin(x * 0.26 + uTime * 0.27 + uPlace.w);
}

vec3 ribbonPoint(float s, float v, float n, float layer, out vec3 normal) {
  vec3 c0 = centerLocal(s);
  vec3 c1 = centerLocal(s + 0.004);
  vec3 tangent = normalize(c1 - c0);
  vec3 up = vec3(0.0, 1.0, 0.0);
  vec3 n0 = normalize(up - tangent * dot(up, tangent));
  vec3 b0 = cross(tangent, n0);
  float th = twistAt(s, layer);
  vec3 across = cos(th) * n0 + sin(th) * b0;
  vec3 sheet = -sin(th) * n0 + cos(th) * b0;
  float halfWidth = uWidth * (0.78 + 0.22 * cos(s * 3.14159));
  vec3 local = c0 + across * v * halfWidth + sheet * (n + layer * uVolume * 0.16) * halfWidth;
  normal = uOrient * sheet;
  return uOrient * (local * uScale);
}
`;

  const DOT_VERT = HEADER + SHAPE + `
uniform mat4 uViewProj;
uniform vec3 uEye;
uniform vec2 uViewport;
uniform float uDpr;
uniform float uFibers;
uniform float uDots;
uniform float uFlow;
uniform float uSize;
uniform float uFocus;
uniform float uDof;
uniform float uMaxCoc;
uniform float uFocal;
uniform float uIntro;
uniform float uDepthSpread;
uniform float uGain;
uniform float uTint;
uniform float uGradient;
uniform float uFold;
uniform float uSparkle;

out vec2 vLocal;
out float vRadius;
out float vSegment;
out vec3 vLight;
out float vTint;

void main() {
  int perFiber = int(uDots);
  int fiber = gl_InstanceID / perFiber;
  int bead = gl_InstanceID - fiber * perFiber;
  float fi = float(fiber);
  float fk = float(bead);

  float seed = hash11(fi * 1.731 + uRibbon * 17.0);
  float s = fract((fk + uFlow + seed * uDots) / uDots) - 0.5;
  float sNext = s + 1.0 / uDots;
  float layer = mod(fi, 3.0) - 1.0;
  float slot = floor(fi / 3.0);
  float perLayer = max(floor(uFibers / 3.0), 1.0);
  float v = ((slot + 0.5) / perLayer) * 2.0 - 1.0 + (hash11(fi * 3.113 + 4.0) - 0.5) * (1.6 / perLayer) + layer * 0.12 / perLayer;
  float depthOffset = (hash11(fi * 7.919 + 2.0) - 0.5) * uDepthSpread * (0.35 + 6.0 * s * s);

  vec3 normal;
  vec3 world = ribbonPoint(s, v, depthOffset, layer, normal);
  vec3 nextNormal;
  vec3 nextWorld = ribbonPoint(sNext, v, depthOffset, layer, nextNormal);

  vec4 clip = uViewProj * vec4(world, 1.0);
  float depth = clip.w;
  vec2 p0 = (clip.xy / clip.w * 0.5 + 0.5) * uViewport;

  float baseRadius = max(0.5 * uSize * uDpr * uFocal / max(depth, 0.1), 0.45);
  float coc = min(uDof * abs(1.0 - uFocus / max(depth, 0.1)) * uViewport.y * 0.035, uMaxCoc * uDpr);
  float radius = baseRadius + coc;
  float spill = max(10.0 * uDpr, baseRadius);
  float energy = pow(baseRadius / min(radius, spill), 1.25) * pow(min(1.0, spill / radius), 2.0);

  vec3 toEye = normalize(uEye - world);
  float facing = abs(dot(normalize(normal), toEye));
  float fold = pow(1.0 - facing, 6.0) * uFold;
  float endFade = smoothstep(0.5, 0.4, abs(s)) * smoothstep(1.6, 4.2, depth);
  float appear = smoothstep(0.0, 0.12, uIntro * 1.3 - (s + 0.5) - seed * 0.12);
  float twinklePhase = hash11(fi * 13.7 + fk * 0.917 + uRibbon * 3.0);
  float twinkle = pow(max(sin(uTime * (1.2 + 2.6 * twinklePhase) * 3.0 + twinklePhase * 61.0), 0.0), 36.0) * uSparkle;
  float strength = mix(0.45, 1.0, hash11(fi * 5.37 + 1.0)) * mix(1.0, 0.72, abs(layer) * uVolume);
  float intensity = energy * strength * endFade * appear * 0.8 * uGain * (1.0 + fold * 7.0 + twinkle * 5.0);
  float highlight = clamp(fold * 0.55 + twinkle, 0.0, 1.0);

  // "Dots" style: every bead is a round bokeh disc.
  vec2 axis = vec2(1.0, 0.0);
  vec2 corner = vec2(gl_VertexID == 1 || gl_VertexID == 3 ? 1.0 : 0.0, gl_VertexID >= 2 ? 1.0 : 0.0);
  vec2 position = p0 + vec2(mix(-radius, radius, corner.x), mix(-radius, radius, corner.y));

  vLocal = vec2(mix(-radius, radius, corner.x), mix(-radius, radius, corner.y));
  vRadius = radius;
  vSegment = 0.0;
  vLight = vec3(intensity, highlight, coc / max(radius, 1e-3));
  float depthTint = clamp(uTint + smoothstep(uFocus, uFocus + 5.0, depth) * 0.5, 0.0, 1.0);
  vTint = uGradient < 0.5 ? depthTint : uGradient < 1.5 ? smoothstep(-0.42, 0.42, s) : clamp(v * 0.5 + 0.5, 0.0, 1.0);
  if (intensity < 0.0005) position = vec2(-1e4);
  gl_Position = vec4(position / uViewport * 2.0 - 1.0, 0.0, 1.0);
}`;

  const DUST_VERT = HEADER + `
uniform mat4 uViewProj;
uniform vec2 uViewport;
uniform float uDpr;
uniform float uTime;
uniform float uSize;
uniform float uFocus;
uniform float uDof;
uniform float uFocal;
uniform float uIntro;
uniform float uSparkle;
uniform float uScale;
uniform float uGain;
uniform float uGradient;

out vec2 vLocal;
out float vRadius;
out float vSegment;
out vec3 vLight;
out float vTint;

float hash11(float n) { return fract(sin(n * 91.3458) * 47453.5453); }

void main() {
  float id = float(gl_InstanceID);
  vec3 seed = vec3(hash11(id * 1.37 + 0.3), hash11(id * 2.91 + 1.7), hash11(id * 4.17 + 2.9));
  vec3 box = vec3(9.0, 5.4, 6.0);
  vec3 p = (seed - 0.5) * box;
  p.z -= 0.6;
  p += 0.18 * vec3(sin(uTime * 0.21 + seed.x * 40.0), sin(uTime * 0.17 + seed.y * 40.0), sin(uTime * 0.13 + seed.z * 40.0));
  p *= mix(1.0, uScale, 0.5);
  vec4 clip = uViewProj * vec4(p, 1.0);
  float depth = clip.w;
  vec2 px = (clip.xy / clip.w * 0.5 + 0.5) * uViewport;
  float size = uSize * mix(0.5, 1.4, hash11(id * 7.7));
  float baseRadius = max(0.5 * size * uDpr * uFocal / max(depth, 0.1), 0.45);
  float coc = min(uDof * abs(1.0 - uFocus / max(depth, 0.1)) * uViewport.y * 0.035, 22.0 * uDpr * 1.6);
  float radius = baseRadius + coc;
  float spill = max(10.0 * uDpr, baseRadius);
  float energy = pow(baseRadius / min(radius, spill), 0.9) * pow(min(1.0, spill / radius), 2.0);
  float twinkle = pow(max(sin(uTime * (0.8 + 1.6 * seed.y) * 2.0 + seed.z * 50.0), 0.0), 8.0);
  float intensity = energy * (0.35 + 0.65 * twinkle) * mix(0.4, 1.0, seed.x) * smoothstep(0.3, 1.0, uIntro) * (depth > 0.2 ? 1.0 : 0.0);
  vec2 corner = (vec2(gl_VertexID == 1 || gl_VertexID == 3 ? 1.0 : 0.0, gl_VertexID >= 2 ? 1.0 : 0.0)) * 2.0 - 1.0;
  vec2 position = px + corner * radius;
  vLocal = corner * radius;
  vRadius = radius;
  vSegment = 0.0;
  vLight = vec3(intensity * 0.8 * uGain, 0.3 + 0.6 * twinkle * uSparkle, coc / max(radius, 1e-3));
  vTint = seed.y;
  gl_Position = vec4(position / uViewport * 2.0 - 1.0, 0.0, 1.0);
}`;

  const DOT_FRAG = HEADER + `
uniform vec3 uGlowColor;
uniform vec3 uLineColor;
uniform vec3 uSecondaryColor;
in vec2 vLocal;
in float vRadius;
in float vSegment;
in vec3 vLight;
in float vTint;
out vec4 outColor;
void main() {
  float along = clamp(vLocal.x, 0.0, vSegment);
  float d = length(vec2(vLocal.x - along, vLocal.y));
  float rho = d / max(vRadius, 1e-3);
  if (rho > 1.0) discard;
  float soft = clamp(2.6 / max(vRadius, 1e-3), 0.14, 1.0);
  float disk = 1.0 - smoothstep(1.0 - soft, 1.0, rho);
  float bokeh = disk * (0.94 + 0.08 * smoothstep(0.55, 0.95, rho));
  float core = exp(-rho * rho * 3.2);
  float shape = mix(core, bokeh, smoothstep(0.25, 0.7, vLight.z));
  vec3 color = mix(mix(uGlowColor, uSecondaryColor, vTint), uLineColor, vLight.y);
  outColor = vec4(color * shape * vLight.x, shape * vLight.x);
}`;

  const FULL_VERT = HEADER + `
out vec2 vUv;
void main() {
  vec2 p = vec2(gl_VertexID == 1 ? 3.0 : -1.0, gl_VertexID == 2 ? 3.0 : -1.0);
  vUv = p * 0.5 + 0.5;
  gl_Position = vec4(p, 0.0, 1.0);
}`;

  const BRIGHT_FRAG = HEADER + `
uniform sampler2D uSource;
uniform vec2 uTexel;
in vec2 vUv;
out vec4 outColor;
vec3 pick(vec2 uv) {
  vec3 c = texture(uSource, uv).rgb;
  float peak = max(max(c.r, c.g), c.b);
  return c * smoothstep(0.35, 1.2, peak);
}
void main() {
  vec2 o = uTexel;
  vec3 c = pick(vUv + vec2(-o.x, -o.y)) + pick(vUv + vec2(o.x, -o.y)) + pick(vUv + vec2(-o.x, o.y)) + pick(vUv + vec2(o.x, o.y));
  outColor = vec4(c * 0.25, 1.0);
}`;

  const COMPOSITE_FRAG = HEADER + `
uniform sampler2D uScene;
uniform sampler2D uBloom;
uniform vec2 uBloomTexel;
uniform float uGlow;
uniform float uBrightness;
uniform float uGrain;
uniform float uVignette;
uniform float uFrame;
uniform vec2 uView;
uniform float uDpr;
in vec2 vUv;
out vec4 outColor;

float hash(vec2 p) {
  vec3 q = fract(vec3(p.xyx) * 0.1031);
  q += dot(q, q.yzx + 33.33);
  return fract((q.x + q.y) * q.z);
}
float smoother(float x) {
  x = clamp(x, 0.0, 1.0);
  return x * x * x * (x * (x * 6.0 - 15.0) + 10.0);
}
void main() {
  vec4 scene = texture(uScene, vUv);
  vec3 bloom = vec3(0.0);
  for (int i = -2; i <= 2; i++) {
    for (int j = -2; j <= 2; j++) {
      bloom += texture(uBloom, vUv + vec2(float(i), float(j)) * uBloomTexel).rgb;
    }
  }
  bloom /= 25.0;
  vec3 light = (scene.rgb + bloom * uGlow) * uBrightness;
  float reach = max(uVignette * 0.3, 1e-4);
  float mask = uVignette > 0.0
    ? smoother(vUv.x / reach) * smoother((1.0 - vUv.x) / reach) * smoother(vUv.y / reach) * smoother((1.0 - vUv.y) / reach)
    : 1.0;
  vec2 cell = floor(vUv * uView / max(uDpr, 1.0));
  float grain = hash(cell + uFrame * 17.31) + hash(cell * 1.31 + uFrame * 3.7 + 9.1) - 1.0;
  vec3 color = (1.0 - exp(-light * 1.25)) * mask;
  float peak = max(color.r, max(color.g, color.b));
  color = max(color + grain * uGrain * (0.25 + 0.75 * sqrt(peak)), 0.0);
  outColor = vec4(color, max(color.r, max(color.g, color.b)));
}`;

  const DOT_UNIFORMS = [
    'uTime', 'uTwist', 'uRoll', 'uWaves', 'uWidth', 'uRibbon', 'uOrient', 'uScale', 'uPlace', 'uVolume',
    'uViewProj', 'uEye', 'uViewport', 'uDpr', 'uFibers', 'uDots', 'uFlow', 'uSize', 'uFocus', 'uDof',
    'uMaxCoc', 'uFocal', 'uIntro', 'uDepthSpread', 'uGain', 'uTint', 'uGradient', 'uFold', 'uSparkle',
    'uGlowColor', 'uLineColor', 'uSecondaryColor'
  ];
  const DUST_UNIFORMS = [
    'uViewProj', 'uViewport', 'uDpr', 'uTime', 'uSize', 'uFocus', 'uDof', 'uFocal', 'uIntro',
    'uSparkle', 'uScale', 'uGain', 'uGlowColor', 'uLineColor', 'uSecondaryColor'
  ];
  const COMPOSITE_UNIFORMS = [
    'uScene', 'uBloom', 'uBloomTexel', 'uGlow', 'uBrightness', 'uGrain', 'uVignette', 'uFrame', 'uView', 'uDpr'
  ];

  const clamp = (value, min, max) => Math.min(max, Math.max(min, value));

  function hexToRgb(hex, fallback) {
    const match = /^#?([0-9a-f]{6}|[0-9a-f]{3})$/i.exec(String(hex || '').trim());
    if (!match) return fallback;
    let h = match[1];
    if (h.length === 3) h = h.split('').map(c => c + c).join('');
    const n = parseInt(h, 16);
    return [((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255];
  }

  function compile(gl, type, source) {
    const shader = gl.createShader(type);
    gl.shaderSource(shader, source);
    gl.compileShader(shader);
    if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
      console.error('[GhostFibers] shader error:', gl.getShaderInfoLog(shader));
      gl.deleteShader(shader);
      return null;
    }
    return shader;
  }

  function link(gl, vertexSource, fragmentSource, names) {
    const vs = compile(gl, gl.VERTEX_SHADER, vertexSource);
    const fs = compile(gl, gl.FRAGMENT_SHADER, fragmentSource);
    if (!vs || !fs) return null;
    const program = gl.createProgram();
    gl.attachShader(program, vs);
    gl.attachShader(program, fs);
    gl.linkProgram(program);
    gl.deleteShader(vs);
    gl.deleteShader(fs);
    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
      console.error('[GhostFibers] link error:', gl.getProgramInfoLog(program));
      return null;
    }
    const uniforms = {};
    names.forEach(n => { uniforms[n] = gl.getUniformLocation(program, n); });
    return { program, uniforms };
  }

  function frustum(fov, aspect, near, far) {
    const f = 1 / Math.tan(fov / 2);
    const nf = 1 / (near - far);
    return [f / aspect, 0, 0, 0, 0, f, 0, 0, 0, 0, (far + near) * nf, -1, 0, 0, 2 * far * near * nf, 0];
  }

  function multiply4(a, b) {
    const out = new Array(16);
    for (let col = 0; col < 4; col++) {
      for (let row = 0; row < 4; row++) {
        out[col * 4 + row] =
          a[row] * b[col * 4] + a[4 + row] * b[col * 4 + 1] + a[8 + row] * b[col * 4 + 2] + a[12 + row] * b[col * 4 + 3];
      }
    }
    return out;
  }

  function multiply3(a, b) {
    const out = new Array(9);
    for (let col = 0; col < 3; col++) {
      for (let row = 0; row < 3; row++) {
        out[col * 3 + row] = a[row] * b[col * 3] + a[3 + row] * b[col * 3 + 1] + a[6 + row] * b[col * 3 + 2];
      }
    }
    return out;
  }

  function orientation(yaw, pitch, roll) {
    const cy = Math.cos(yaw), sy = Math.sin(yaw);
    const cp = Math.cos(pitch), sp = Math.sin(pitch);
    const cr = Math.cos(roll), sr = Math.sin(roll);
    const ry = [cy, 0, -sy, 0, 1, 0, sy, 0, cy];
    const rx = [1, 0, 0, 0, cp, sp, 0, -sp, cp];
    const rz = [cr, sr, 0, -sr, cr, 0, 0, 0, 1];
    return multiply3(rz, multiply3(rx, ry));
  }

  function mount(container, options) {
    const o = Object.assign({}, DEFAULTS, options || {});
    const canvas = document.createElement('canvas');
    canvas.className = 'ghost-fibers-canvas';
    canvas.setAttribute('aria-hidden', 'true');
    container.appendChild(canvas);

    const gl = canvas.getContext('webgl2', {
      alpha: true, premultipliedAlpha: true, antialias: false, depth: false, stencil: false
    });
    const fallback = {
      destroy() {
        canvas.remove();
        container.classList.add('no-webgl');
      }
    };
    if (!gl) return fallback;

    const floatTargets = !!gl.getExtension('EXT_color_buffer_float');
    const dots = link(gl, DOT_VERT, DOT_FRAG, DOT_UNIFORMS);
    const dust = link(gl, DUST_VERT, DOT_FRAG, DUST_UNIFORMS);
    const bright = link(gl, FULL_VERT, BRIGHT_FRAG, ['uSource', 'uTexel']);
    const composite = link(gl, FULL_VERT, COMPOSITE_FRAG, COMPOSITE_UNIFORMS);
    if (!dots || !dust || !bright || !composite) return fallback;

    const glowC = hexToRgb(o.glowColor, [0.55, 0.36, 0.96]);
    const lineC = o.lineColor ? hexToRgb(o.lineColor, glowC) : glowC.map(c => c + (1 - c) * 0.72);
    const secC = o.secondaryColor ? hexToRgb(o.secondaryColor, glowC) : glowC.map(c => c * 0.8);
    const gradient = GRADIENTS[o.gradient] ?? 0;
    const threads = clamp(Math.round(o.threads), 6, 180);
    const layers = clamp(Math.round(o.layers), 1, 3);
    const density = clamp(o.density, 0.2, 3);
    const dotsPerFiber = Math.round(260 * density);
    const thickness = clamp(o.thickness, 0.2, 4);
    const spread = clamp(o.spread, 0.2, 3);
    const scale = clamp(o.scale, 0.3, 3);
    const volume = clamp(o.volume, 0, 2);
    const particles = clamp(o.particles, 0, 2);
    const sparkle = clamp(o.sparkle, 0, 2);
    const roll0 = o.rotation * DEG;
    const area = Math.pow(Math.max(0.8 * thickness, 0.45), 2) / 0.64;
    const load = Math.pow((threads / 72) * density * area, -0.75);
    const blurCap = 22 * clamp(Math.sqrt(56000 / (threads * dotsPerFiber * layers)), 0.45, 1);
    const reduce = global.matchMedia ? global.matchMedia('(prefers-reduced-motion: reduce)').matches : false;

    const format = floatTargets ? gl.RGBA16F : gl.RGBA8;
    const makeTarget = () => ({ tex: null, fbo: gl.createFramebuffer(), w: 0, h: 0 });
    const alloc = (t, w, h) => {
      if (t.tex && t.w === w && t.h === h) return;
      if (t.tex) gl.deleteTexture(t.tex);
      t.tex = gl.createTexture();
      gl.bindTexture(gl.TEXTURE_2D, t.tex);
      gl.texStorage2D(gl.TEXTURE_2D, 1, format, w, h);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      gl.bindFramebuffer(gl.FRAMEBUFFER, t.fbo);
      gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, t.tex, 0);
      t.w = w;
      t.h = h;
    };
    const scene = makeTarget();
    const bloom = makeTarget();
    const vao = gl.createVertexArray();

    const st = {
      time: 0, roll: 0, flow: 0, frame: 0,
      intro: (o.intro && !reduce) ? 0 : INTRO_SECONDS,
      w: 1, h: 1, fit: 1,
      look: { x: 0, y: 0 },
      target: { x: 0, y: 0 }
    };
    let raf = 0;
    let last = 0;
    let visible = true;
    let alive = true;

    const bindTex = (unit, tex) => {
      gl.activeTexture(gl.TEXTURE0 + unit);
      gl.bindTexture(gl.TEXTURE_2D, tex);
    };

    const cameraFor = () => {
      const aspect = st.w / Math.max(st.h, 1);
      const proj = frustum(FOV, aspect, 0.1, 60);
      const view = [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, -CAMERA, 1];
      const orient = orientation(
        o.perspective * 0.85 + st.look.x * 0.22,
        0.12 - st.look.y * 0.14,
        roll0
      );
      return { viewProj: multiply4(proj, view), orient };
    };

    const render = () => {
      if (!alive) return;
      const ratio = canvas.height / Math.max(st.h, 1);
      const t = clamp(st.intro / INTRO_SECONDS, 0, 1);
      const introEase = 1 - Math.pow(1 - t, 3);
      const camera = cameraFor();

      alloc(scene, canvas.width, canvas.height);
      gl.bindVertexArray(vao);
      gl.bindFramebuffer(gl.FRAMEBUFFER, scene.fbo);
      gl.viewport(0, 0, canvas.width, canvas.height);
      gl.clearColor(0, 0, 0, 0);
      gl.clear(gl.COLOR_BUFFER_BIT);
      gl.enable(gl.BLEND);
      gl.blendFunc(gl.ONE, gl.ONE);

      // Fibers
      gl.useProgram(dots.program);
      const u = dots.uniforms;
      gl.uniform1f(u.uTime, st.time);
      gl.uniform1f(u.uTwist, o.twist);
      gl.uniform1f(u.uRoll, st.roll);
      gl.uniform1f(u.uWaves, o.waves);
      gl.uniform1f(u.uWidth, 0.62 * spread);
      gl.uniformMatrix3fv(u.uOrient, false, camera.orient);
      gl.uniform1f(u.uScale, scale * st.fit);
      gl.uniformMatrix4fv(u.uViewProj, false, camera.viewProj);
      gl.uniform3f(u.uEye, 0, 0, CAMERA);
      gl.uniform2f(u.uViewport, canvas.width, canvas.height);
      gl.uniform1f(u.uDpr, ratio);
      gl.uniform1f(u.uFibers, threads);
      gl.uniform1f(u.uDots, dotsPerFiber);
      gl.uniform1f(u.uFlow, st.flow);
      gl.uniform1f(u.uSize, 1.6 * thickness);
      gl.uniform1f(u.uFocus, CAMERA);
      gl.uniform1f(u.uDof, o.depthOfField);
      gl.uniform1f(u.uMaxCoc, blurCap);
      gl.uniform1f(u.uFocal, CAMERA);
      gl.uniform1f(u.uIntro, introEase);
      gl.uniform1f(u.uDepthSpread, 0.12);
      gl.uniform1f(u.uVolume, volume);
      gl.uniform1f(u.uSparkle, sparkle);
      gl.uniform1f(u.uFold, o.foldGlow);
      gl.uniform1f(u.uGradient, gradient);
      gl.uniform3f(u.uGlowColor, glowC[0], glowC[1], glowC[2]);
      gl.uniform3f(u.uLineColor, lineC[0], lineC[1], lineC[2]);
      gl.uniform3f(u.uSecondaryColor, secC[0], secC[1], secC[2]);
      for (let r = 0; r < layers; r++) {
        const place = PLACEMENTS[r];
        gl.uniform1f(u.uRibbon, r);
        gl.uniform4f(u.uPlace, place[0], place[1], place[2], place[3]);
        gl.uniform1f(u.uGain, RIBBON_GAIN[r] * load);
        gl.uniform1f(u.uTint, RIBBON_TINT[r]);
        gl.drawArraysInstanced(gl.TRIANGLE_STRIP, 0, 4, threads * dotsPerFiber);
      }

      // Dust
      const dustCount = Math.round(420 * particles);
      if (dustCount > 0) {
        gl.useProgram(dust.program);
        const d = dust.uniforms;
        gl.uniformMatrix4fv(d.uViewProj, false, camera.viewProj);
        gl.uniform2f(d.uViewport, canvas.width, canvas.height);
        gl.uniform1f(d.uDpr, ratio);
        gl.uniform1f(d.uTime, st.time);
        gl.uniform1f(d.uSize, 2.2 * thickness);
        gl.uniform1f(d.uFocus, CAMERA);
        gl.uniform1f(d.uDof, o.depthOfField);
        gl.uniform1f(d.uFocal, CAMERA);
        gl.uniform1f(d.uIntro, introEase);
        gl.uniform1f(d.uSparkle, sparkle);
        gl.uniform1f(d.uScale, scale * st.fit);
        gl.uniform1f(d.uGain, 1 / thickness);
        gl.uniform3f(d.uGlowColor, glowC[0], glowC[1], glowC[2]);
        gl.uniform3f(d.uLineColor, lineC[0], lineC[1], lineC[2]);
        gl.uniform3f(d.uSecondaryColor, secC[0], secC[1], secC[2]);
        gl.drawArraysInstanced(gl.TRIANGLE_STRIP, 0, 4, dustCount);
      }
      gl.disable(gl.BLEND);

      // Bloom (bright pass into a quarter-resolution buffer; blurred in the composite)
      const blooming = o.glow > 0.001;
      if (blooming) {
        alloc(bloom, Math.max(1, canvas.width >> 2), Math.max(1, canvas.height >> 2));
        gl.bindFramebuffer(gl.FRAMEBUFFER, bloom.fbo);
        gl.viewport(0, 0, bloom.w, bloom.h);
        gl.useProgram(bright.program);
        bindTex(0, scene.tex);
        gl.uniform1i(bright.uniforms.uSource, 0);
        gl.uniform2f(bright.uniforms.uTexel, 1.5 / scene.w, 1.5 / scene.h);
        gl.drawArrays(gl.TRIANGLES, 0, 3);
      }

      // Composite to the canvas
      gl.bindFramebuffer(gl.FRAMEBUFFER, null);
      gl.viewport(0, 0, canvas.width, canvas.height);
      gl.clearColor(0, 0, 0, 0);
      gl.clear(gl.COLOR_BUFFER_BIT);
      gl.useProgram(composite.program);
      const c = composite.uniforms;
      bindTex(0, scene.tex);
      bindTex(1, blooming ? bloom.tex : scene.tex);
      gl.uniform1i(c.uScene, 0);
      gl.uniform1i(c.uBloom, 1);
      gl.uniform2f(c.uBloomTexel, 2 / Math.max(bloom.w, 1), 2 / Math.max(bloom.h, 1));
      gl.uniform1f(c.uGlow, blooming ? o.glow : 0);
      gl.uniform1f(c.uBrightness, o.brightness);
      gl.uniform1f(c.uGrain, o.grain);
      gl.uniform1f(c.uVignette, o.vignette);
      gl.uniform1f(c.uFrame, st.frame % 977);
      gl.uniform2f(c.uView, canvas.width, canvas.height);
      gl.uniform1f(c.uDpr, ratio);
      gl.drawArrays(gl.TRIANGLES, 0, 3);
      bindTex(1, null);
      bindTex(0, null);
      gl.bindVertexArray(null);
    };

    const resize = () => {
      const w = Math.max(1, container.clientWidth);
      const h = Math.max(1, container.clientHeight);
      const base = Math.min(global.devicePixelRatio || 1, 2);
      const longest = Math.max(w, h) * base;
      const ratio = longest > MAX_DIM ? (base * MAX_DIM) / longest : base;
      canvas.width = Math.max(1, Math.round(w * ratio));
      canvas.height = Math.max(1, Math.round(h * ratio));
      st.w = w;
      st.h = h;
      st.fit = clamp(w / h / 1.5, 0.6, 1);
      wake();
    };

    const frame = now => {
      raf = 0;
      if (!alive || !visible || document.hidden) {
        last = 0;
        return;
      }
      const dt = last ? Math.min(0.05, (now - last) / 1000) : 1 / 60;
      last = now;
      if (!reduce) {
        st.frame += 1;
        st.time += dt * o.speed;
        st.roll += dt * o.speed * o.rollSpeed;
        st.flow += dt * o.flow * 12;
      }
      st.intro = Math.min(INTRO_SECONDS, st.intro + dt);
      const k = 1 - Math.exp(-dt / 0.35);
      st.look.x += (st.target.x - st.look.x) * k;
      st.look.y += (st.target.y - st.look.y) * k;

      render();
      if (!reduce) raf = requestAnimationFrame(frame);
    };

    const wake = () => {
      if (!raf && alive && visible && !document.hidden) {
        last = 0;
        raf = requestAnimationFrame(frame);
      }
    };

    const onPointerMove = e => {
      if (!o.mouseInteraction) return;
      const r = container.getBoundingClientRect();
      st.target.x = ((e.clientX - r.left) / Math.max(r.width, 1) - 0.5) * 0.5;
      st.target.y = (0.5 - (e.clientY - r.top) / Math.max(r.height, 1)) * 0.5;
      wake();
    };
    const onPointerLeave = () => {
      st.target.x = 0;
      st.target.y = 0;
      wake();
    };
    const onVisibility = () => wake();

    const resizeObserver = new ResizeObserver(resize);
    resizeObserver.observe(container);
    const intersection = new IntersectionObserver(entries => {
      visible = entries.some(entry => entry.isIntersecting);
      if (visible) wake();
    });
    intersection.observe(container);
    global.addEventListener('pointermove', onPointerMove, { passive: true });
    document.documentElement.addEventListener('pointerleave', onPointerLeave);
    document.addEventListener('visibilitychange', onVisibility);

    resize();

    return {
      destroy() {
        alive = false;
        cancelAnimationFrame(raf);
        resizeObserver.disconnect();
        intersection.disconnect();
        global.removeEventListener('pointermove', onPointerMove);
        document.documentElement.removeEventListener('pointerleave', onPointerLeave);
        document.removeEventListener('visibilitychange', onVisibility);
        gl.deleteVertexArray(vao);
        [scene, bloom].forEach(t => {
          if (t.tex) gl.deleteTexture(t.tex);
          gl.deleteFramebuffer(t.fbo);
        });
        [dots, dust, bright, composite].forEach(p => gl.deleteProgram(p.program));
        canvas.remove();
      }
    };
  }

  global.GhostFibers = { mount };
})(window);

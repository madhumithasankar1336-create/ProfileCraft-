/* ProfileCraft - frontend application logic */
(() => {
  'use strict';

  const API = '/api/profiles';
  const MAX_IMAGE_BYTES = 2 * 1024 * 1024;
  const THEMES = [
    ['modern', 'Modern'], ['professional', 'Professional'], ['minimal', 'Minimal'],
    ['gradient', 'Gradient'], ['glassmorphism', 'Glass'],
  ];
  const TEMPLATES = [[1, 'Classic'], [2, 'Banner'], [3, 'Split'], [4, 'Compact'], [5, 'Spotlight']];
  const SOCIAL = [
    ['linkedin', 'fa-brands fa-linkedin-in', 'LinkedIn'],
    ['github', 'fa-brands fa-github', 'GitHub'],
    ['instagram', 'fa-brands fa-instagram', 'Instagram'],
    ['portfolio', 'fa-solid fa-globe', 'Portfolio'],
  ];
  const TEXT_FIELDS = ['full_name', 'username', 'email', 'title', 'location', 'bio', 'image_url'];
  const SOCIAL_FIELDS = ['linkedin', 'github', 'instagram', 'portfolio'];

  // Client-side rules mirror the backend validation in app.py.
  const RULES = {
    full_name: { required: true, max: 80 },
    username: { required: true, pattern: /^[A-Za-z0-9_]{3,30}$/, message: '3-30 letters, numbers or underscores' },
    email: { required: true, max: 120, pattern: /^[^\s@]+@[^\s@]+\.[^\s@]+$/, message: 'Enter a valid email address' },
    title: { max: 80 },
    location: { max: 80 },
    bio: { max: 500 },
    image_url: { url: true },
    linkedin: { url: true },
    github: { url: true },
    instagram: { url: true },
    portfolio: { url: true },
  };

  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
  const field = id => document.getElementById(id);
  const esc = value => String(value ?? '').replace(/[&<>"']/g, c => (
    { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
  ));
  const isUrl = value => {
    try { return ['http:', 'https:'].includes(new URL(value).protocol); } catch { return false; }
  };
  const initials = name => (name || '?').split(/\s+/).filter(Boolean).slice(0, 2)
    .map(w => w[0].toUpperCase()).join('') || '?';
  const shareUrl = id => `${location.origin}/p/${id}`;

  const state = {
    profiles: [],
    editingId: null,        // id being edited (PUT)
    currentId: null,        // id of the saved profile shown in preview
    lockedPreview: null,    // saved profile displayed in preview (view mode)
    skills: [],
    interests: [],
    imageFile: null,
    imageDataUrl: '',
    existingImage: '',
    removeImage: false,
    theme: 'modern',
    template: 1,
    search: '',
    favoritesOnly: false,
    pendingDelete: null,
    busy: false,
  };

  // ------------------------------------------------------------ utilities
  function toast(message, type = 'success') {
    const icons = { success: 'fa-circle-check', error: 'fa-circle-exclamation', info: 'fa-circle-info' };
    const el = document.createElement('div');
    el.className = `toast ${type}`;
    el.innerHTML = `<i class="fa-solid ${icons[type] || icons.info}"></i><span></span>`;
    el.querySelector('span').textContent = message;
    field('toasts').appendChild(el);
    setTimeout(() => {
      el.classList.add('out');
      setTimeout(() => el.remove(), 300);
    }, 3200);
  }

  async function api(path, options = {}) {
    let res;
    try {
      res = await fetch(path, options);
    } catch {
      throw Object.assign(new Error('Network error - is the server running?'), { errors: {} });
    }
    let body = {};
    try { body = await res.json(); } catch { body = { success: false, message: `Unexpected response (${res.status})` }; }
    if (!res.ok || body.success === false) {
      throw Object.assign(new Error(body.message || 'Request failed'), { errors: body.errors || {}, status: res.status });
    }
    return body;
  }

  function setBusy(button, busy, label) {
    if (!button) return;
    if (busy) {
      button.dataset.label = button.innerHTML;
      button.innerHTML = '<span class="spinner"></span> Please wait';
      button.disabled = true;
    } else {
      button.innerHTML = label || button.dataset.label || button.innerHTML;
      button.disabled = false;
    }
  }

  async function copyText(text) {
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      const area = document.createElement('textarea');
      area.value = text;
      document.body.appendChild(area);
      area.select();
      document.execCommand('copy');
      area.remove();
    }
    toast('Link copied to clipboard');
  }

  const openModal = id => field(id).classList.add('open');
  const closeModal = id => field(id).classList.remove('open');

  // ------------------------------------------------------------ data model
  const COMPLETION_CHECKS = [
    p => p.full_name, p => p.username, p => p.email, p => p.bio, p => p.location,
    p => p.title, p => p.image, p => p.skills.length, p => p.interests.length,
    p => Object.values(p.social || {}).some(Boolean),
  ];
  const completionOf = p => Math.round(
    COMPLETION_CHECKS.filter(check => !!check(p)).length / COMPLETION_CHECKS.length * 100
  );

  function formValues() {
    const v = {};
    [...TEXT_FIELDS, ...SOCIAL_FIELDS].forEach(id => { v[id] = field(id).value.trim(); });
    return {
      full_name: v.full_name,
      username: v.username,
      email: v.email,
      title: v.title,
      location: v.location,
      bio: v.bio,
      image_url: v.image_url,
      social: { linkedin: v.linkedin, github: v.github, instagram: v.instagram, portfolio: v.portfolio },
      skills: [...state.skills],
      interests: [...state.interests],
      theme: state.theme,
      template: state.template,
    };
  }

  function currentImage() {
    return state.imageDataUrl || field('image_url').value.trim() || state.existingImage || '';
  }

  function previewProfile() {
    const p = formValues();
    p.image = currentImage();
    p.id = state.currentId;
    return p;
  }

  // ------------------------------------------------------------ rendering
  function cardHTML(p, extraClass = '') {
    const theme = p.theme || 'modern';
    const tpl = Number(p.template) || 1;
    const name = p.full_name || 'Your Name';
    const user = p.username ? `@${p.username}` : '@username';
    const social = p.social || {};
    const socials = SOCIAL
      .filter(([key]) => social[key])
      .map(([key, icon, label]) =>
        `<a href="${esc(social[key])}" target="_blank" rel="noopener noreferrer" title="${label}"><i class="${icon}"></i></a>`)
      .join('');
    const chips = (p.skills || []).map(s => `<span class="pc-chip">${esc(s)}</span>`).join('');
    const interests = (p.interests || []).map(s => `<span class="pc-interest">${esc(s)}</span>`).join('');
    return `
      <article class="pc-card theme-${esc(theme)} tpl-${tpl} ${extraClass}">
        <div class="pc-cover"></div>
        <div class="pc-avatar">
          <span class="pc-initials">${esc(initials(name))}</span>
          ${p.image ? `<img src="${esc(p.image)}" alt="" onerror="this.remove()">` : ''}
        </div>
        <div class="pc-info">
          <h3 class="pc-name">${esc(name)}</h3>
          <p class="pc-user">${esc(user)}</p>
          ${p.title ? `<p class="pc-title">${esc(p.title)}</p>` : ''}
          ${p.location ? `<p class="pc-meta"><i class="fa-solid fa-location-dot"></i>${esc(p.location)}</p>` : ''}
          ${p.bio ? `<p class="pc-bio">${esc(p.bio)}</p>` : ''}
          ${chips ? `<div class="pc-chips">${chips}</div>` : ''}
          ${interests ? `<div class="pc-interests"><span class="pc-label">Interests</span>${interests}</div>` : ''}
          ${socials ? `<div class="pc-socials">${socials}</div>` : ''}
        </div>
      </article>`;
  }

  function renderPreview() {
    const p = state.lockedPreview || previewProfile();
    field('previewStage').innerHTML = cardHTML(p);
    const pct = completionOf(p);
    field('completionFill').style.width = `${pct}%`;
    field('completionText').textContent = `${pct}% complete`;
    const saved = !!state.currentId;
    field('copyLink').disabled = !saved;
    field('shareBtn').disabled = !saved;
    field('imagePreviewBox').innerHTML = p.image
      ? `<img src="${esc(p.image)}" alt="" onerror="this.remove()"><i class="fa-regular fa-image" style="display:none"></i>`
      : '<i class="fa-regular fa-image"></i>';
    field('bioCount').textContent = `${field('bio').value.length}/500`;
  }

  function renderTags(key) {
    const listId = key === 'skills' ? 'skillTags' : 'interestTags';
    field(listId).innerHTML = state[key].map((tag, i) =>
      `<span class="tag">${esc(tag)}<button type="button" data-tag="${key}" data-index="${i}" aria-label="Remove ${esc(tag)}">&times;</button></span>`
    ).join('');
  }

  function renderPills() {
    field('themePills').innerHTML = THEMES.map(([value, label]) =>
      `<button type="button" class="pill ${state.theme === value ? 'active' : ''}" data-theme="${value}">${label}</button>`
    ).join('');
    field('templatePills').innerHTML = TEMPLATES.map(([value, label]) =>
      `<button type="button" class="pill ${state.template === value ? 'active' : ''}" data-template="${value}">${value}. ${label}</button>`
    ).join('');
  }

  function profileItemHTML(p) {
    const fav = p.is_favorite;
    return `
      <div class="profile-item" data-id="${p.id}">
        <div class="pi-card" title="Click to preview">${cardHTML(p)}</div>
        <div class="pc-progress"><span style="width:${p.completion}%"></span></div>
        <div class="pi-actions">
          <button class="act ${fav ? 'on' : ''}" data-action="fav" title="${fav ? 'Remove favorite' : 'Add to favorites'}"><i class="${fav ? 'fa-solid' : 'fa-regular'} fa-star"></i></button>
          <button class="act" data-action="edit" title="Edit"><i class="fa-solid fa-pen"></i></button>
          <button class="act" data-action="qr" title="QR code"><i class="fa-solid fa-qrcode"></i></button>
          <button class="act" data-action="download" title="Download PNG"><i class="fa-solid fa-download"></i></button>
          <button class="act" data-action="share" title="Share"><i class="fa-solid fa-share-nodes"></i></button>
          <button class="act" data-action="copy" title="Copy link"><i class="fa-solid fa-link"></i></button>
          <button class="act danger" data-action="delete" title="Delete"><i class="fa-solid fa-trash"></i></button>
        </div>
      </div>`;
  }

  function emptyStateHTML() {
    const searching = state.search || state.favoritesOnly;
    const title = searching ? 'No matching profiles' : 'No profiles yet';
    const text = searching
      ? 'Try a different search or clear the favorites filter.'
      : 'Create your first digital identity card and it will appear here.';
    const action = searching ? '' : '<a href="#create" class="btn btn-primary btn-sm"><i class="fa-solid fa-plus"></i> Create profile</a>';
    return `
      <div class="empty">
        <svg viewBox="0 0 200 150" aria-hidden="true">
          <defs>
            <linearGradient id="eg" x1="0" x2="1"><stop offset="0" stop-color="#8b5cf6"/><stop offset="1" stop-color="#06b6d4"/></linearGradient>
          </defs>
          <ellipse cx="100" cy="140" rx="70" ry="6" fill="rgba(139,92,246,.25)"/>
          <rect x="40" y="30" width="120" height="90" rx="16" fill="url(#eg)" opacity=".85"/>
          <circle cx="100" cy="62" r="16" fill="#fff" opacity=".9"/>
          <rect x="70" y="86" width="60" height="8" rx="4" fill="#fff" opacity=".8"/>
          <rect x="82" y="100" width="36" height="6" rx="3" fill="#fff" opacity=".5"/>
          <g class="float"><circle cx="165" cy="28" r="6" fill="#f472b6"/><path d="M25 50 l4 -10 l4 10 l10 4 l-10 4 l-4 10 l-4 -10 l-10 -4z" fill="#facc15"/></g>
        </svg>
        <h3>${title}</h3>
        <p>${text}</p>
        <div style="margin-top:14px">${action}</div>
      </div>`;
  }

  function renderProfiles() {
    const grid = field('profileGrid');
    field('profileCount').textContent = state.profiles.length ? `(${state.profiles.length})` : '';
    if (!state.profiles.length) {
      grid.innerHTML = emptyStateHTML();
      return;
    }
    grid.innerHTML = state.profiles.map(profileItemHTML).join('');
  }

  function renderSkeletons() {
    field('profileGrid').innerHTML = Array.from({ length: 3 }, () => '<div class="skeleton"></div>').join('');
  }

  function countUp(el, to) {
    const from = Number(el.dataset.v || 0);
    el.dataset.v = String(to);
    const start = performance.now();
    const step = now => {
      const k = Math.min(1, (now - start) / 700);
      el.textContent = Math.round(from + (to - from) * (1 - Math.pow(1 - k, 3)));
      if (k < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }

  function renderStats(data) {
    countUp(field('statTotal'), data.total);
    countUp(field('statFavorites'), data.favorites);
    countUp(field('statSkills'), data.unique_skills);
    countUp(field('statCompletion'), data.avg_completion);

    field('recentList').innerHTML = data.recent.length
      ? data.recent.map(r => `
          <button class="recent-item" data-recent="${r.id}">
            <span class="mini-avatar">${esc(initials(r.full_name))}${r.image ? `<img src="${esc(r.image)}" alt="" onerror="this.remove()">` : ''}</span>
            <span>${esc(r.full_name)}<br><small class="muted">@${esc(r.username)} &middot; ${r.completion}%</small></span>
          </button>`).join('')
      : '<p class="muted-empty">Your newest profiles will appear here.</p>';

    field('topSkills').innerHTML = data.top_skills.length
      ? data.top_skills.map(s => `<span class="tag">${esc(s.name)} <small class="muted">&times;${s.count}</small></span>`).join('')
      : '<p class="muted-empty">Add skills to see trends here.</p>';
  }

  // ------------------------------------------------------------ validation
  function setFieldError(id, message) {
    const wrap = field(id)?.closest('.field');
    if (!wrap) return;
    wrap.classList.toggle('invalid', !!message);
    const text = wrap.querySelector('.error-text');
    if (text) text.textContent = message || '';
  }

  function validateField(id) {
    const rule = RULES[id];
    if (!rule) return true;
    const value = field(id).value.trim();
    let message = '';
    if (rule.required && !value) message = 'This field is required';
    else if (value && rule.max && value.length > rule.max) message = `Maximum ${rule.max} characters`;
    else if (value && rule.pattern && !rule.pattern.test(value)) message = rule.message;
    else if (value && rule.url && !isUrl(value)) message = 'Enter a valid http(s) URL';
    setFieldError(id, message);
    return !message;
  }

  function validateForm() {
    const results = Object.keys(RULES).map(validateField);
    return results.every(Boolean);
  }

  function serverErrors(errors) {
    Object.entries(errors).forEach(([key, msg]) => {
      if (key in RULES) setFieldError(key, msg);
    });
  }

  // ------------------------------------------------------------ form state
  function buildFormData() {
    const v = formValues();
    const fd = new FormData();
    ['full_name', 'username', 'email', 'title', 'location', 'bio', 'image_url'].forEach(k => fd.append(k, v[k]));
    fd.append('theme', v.theme);
    fd.append('template', String(v.template));
    fd.append('skills', JSON.stringify(v.skills));
    fd.append('interests', JSON.stringify(v.interests));
    fd.append('social', JSON.stringify(v.social));
    if (state.imageFile) fd.append('image', state.imageFile, state.imageFile.name);
    if (state.removeImage) fd.append('remove_image', '1');
    return fd;
  }

  function setFormMode(editing) {
    field('formTitle').innerHTML = editing
      ? '<i class="fa-solid fa-user-pen"></i> Edit profile'
      : '<i class="fa-solid fa-pen-nib"></i> Create profile';
    field('submitBtn').dataset.label = editing
      ? '<i class="fa-solid fa-floppy-disk"></i> Update profile'
      : '<i class="fa-solid fa-floppy-disk"></i> Save profile';
    field('submitBtn').innerHTML = field('submitBtn').dataset.label;
    field('cancelEdit').classList.toggle('hidden', !editing);
  }

  function clearImageState() {
    state.imageFile = null;
    state.imageDataUrl = '';
    state.existingImage = '';
    state.removeImage = false;
    field('imageFile').value = '';
    field('uploadName').textContent = 'PNG, JPG, GIF or WEBP - max 2 MB';
  }

  function resetForm(silent = false) {
    field('profileForm').reset();
    $$('.field', field('profileForm')).forEach(f => f.classList.remove('invalid'));
    $$('.error-text', field('profileForm')).forEach(e => { e.textContent = ''; });
    state.skills = [];
    state.interests = [];
    state.theme = 'modern';
    state.template = 1;
    state.editingId = null;
    state.currentId = null;
    state.lockedPreview = null;
    clearImageState();
    renderTags('skills');
    renderTags('interests');
    renderPills();
    setFormMode(false);
    renderPreview();
    if (!silent) toast('Form reset', 'info');
  }

  function populateForm(p) {
    TEXT_FIELDS.forEach(k => { field(k).value = p[k] || ''; });
    SOCIAL_FIELDS.forEach(k => { field(k).value = (p.social || {})[k] || ''; });
    state.skills = [...(p.skills || [])];
    state.interests = [...(p.interests || [])];
    state.theme = p.theme || 'modern';
    state.template = Number(p.template) || 1;
    clearImageState();
    state.existingImage = p.image && p.image.startsWith('/static/uploads/') ? p.image : '';
    renderTags('skills');
    renderTags('interests');
    renderPills();
  }

  // ------------------------------------------------------------ actions
  async function loadStats() {
    try {
      const body = await api('/api/stats');
      renderStats(body.data);
    } catch (err) {
      toast(err.message, 'error');
    }
  }

  async function loadProfiles() {
    renderSkeletons();
    const params = new URLSearchParams();
    if (state.search) params.set('q', state.search);
    if (state.favoritesOnly) params.set('favorites', '1');
    try {
      const body = await api(`${API}?${params}`);
      state.profiles = body.data;
      renderProfiles();
    } catch (err) {
      state.profiles = [];
      renderProfiles();
      toast(err.message, 'error');
    }
  }

  async function refreshAll() {
    await Promise.all([loadProfiles(), loadStats()]);
  }

  async function viewProfile(id) {
    try {
      const body = await api(`${API}/${id}`);
      state.currentId = id;
      state.lockedPreview = body.data;
      renderPreview();
      field('create').scrollIntoView({ behavior: 'smooth' });
    } catch (err) {
      toast(err.message, 'error');
    }
  }

  async function startEdit(id) {
    try {
      const body = await api(`${API}/${id}`);
      const p = body.data;
      populateForm(p);
      state.editingId = id;
      state.currentId = id;
      state.lockedPreview = null;
      setFormMode(true);
      renderPreview();
      toast(`Editing @${p.username}`, 'info');
      field('create').scrollIntoView({ behavior: 'smooth' });
    } catch (err) {
      toast(err.message, 'error');
    }
  }

  async function toggleFavorite(id) {
    try {
      const body = await api(`${API}/${id}/favorite`, { method: 'POST' });
      state.profiles = state.profiles.map(p => (p.id === id ? { ...p, is_favorite: body.data.is_favorite } : p));
      if (state.favoritesOnly && !body.data.is_favorite) {
        state.profiles = state.profiles.filter(p => p.id !== id);
      }
      renderProfiles();
      loadStats();
      toast(body.message);
    } catch (err) {
      toast(err.message, 'error');
    }
  }

  function askDelete(id) {
    const p = state.profiles.find(x => x.id === id);
    state.pendingDelete = id;
    field('confirmText').textContent = `"${p ? p.full_name : 'This profile'}" will be permanently removed.`;
    openModal('confirmModal');
  }

  async function confirmDelete() {
    const id = state.pendingDelete;
    if (id == null) return;
    const btn = field('confirmYes');
    setBusy(btn, true);
    try {
      await api(`${API}/${id}`, { method: 'DELETE' });
      if (state.currentId === id || state.editingId === id) resetForm(true);
      toast('Profile deleted');
      await refreshAll();
    } catch (err) {
      toast(err.message, 'error');
    } finally {
      setBusy(btn, false, '<i class="fa-solid fa-trash"></i> Delete');
      state.pendingDelete = null;
      closeModal('confirmModal');
    }
  }

  async function shareProfile(id) {
    const url = shareUrl(id);
    if (navigator.share) {
      try {
        await navigator.share({ title: 'ProfileCraft', text: 'Check out this profile card', url });
      } catch { /* user cancelled */ }
      return;
    }
    copyText(url);
  }

  async function downloadCard(el, filename) {
    if (!el) return toast('Nothing to export', 'error');
    if (!window.html2canvas) return toast('Image export library failed to load', 'error');
    try {
      const canvas = await html2canvas(el, { backgroundColor: null, scale: 2, useCORS: true });
      const link = document.createElement('a');
      link.download = `${filename}.png`;
      link.href = canvas.toDataURL('image/png');
      link.click();
      toast('Card downloaded as PNG');
    } catch {
      toast('Export failed (a remote image may block it). Try uploading the photo instead.', 'error');
    }
  }

  async function showQr(id) {
    if (!id) return toast('Save the profile first to generate its QR code', 'info');
    if (!window.QRCode) return toast('QR library failed to load', 'error');
    const url = shareUrl(id);
    try {
      await QRCode.toCanvas(field('qrCanvas'), url, {
        width: 240, margin: 2, color: { dark: '#1e1b4b', light: '#ffffff' },
      });
      field('qrLink').textContent = url;
      field('qrDownload').href = field('qrCanvas').toDataURL('image/png');
      openModal('qrModal');
    } catch {
      toast('Could not generate QR code', 'error');
    }
  }

  // ------------------------------------------------------------ tags
  const TAG_INPUT = { skills: 'skillInput', interests: 'interestInput' };

  function addTag(key, raw) {
    const tag = raw.replace(/,/g, '').trim().slice(0, 30);
    field(TAG_INPUT[key]).value = '';
    if (!tag) return;
    const list = state[key];
    if (list.length >= 30) return toast('Maximum 30 items allowed', 'error');
    if (list.some(t => t.toLowerCase() === tag.toLowerCase())) return toast(`"${tag}" is already added`, 'info');
    list.push(tag);
    renderTags(key);
    state.lockedPreview = null;
    renderPreview();
  }

  function setupTagInput(key) {
    const input = field(TAG_INPUT[key]);
    input.addEventListener('keydown', e => {
      if (e.key === 'Enter' || e.key === ',') {
        e.preventDefault();
        addTag(key, input.value);
      } else if (e.key === 'Backspace' && !input.value && state[key].length) {
        state[key].pop();
        renderTags(key);
        renderPreview();
      }
    });
    input.addEventListener('blur', () => { if (input.value.trim()) addTag(key, input.value); });
  }

  // ------------------------------------------------------------ image upload
  function handleImageChange(e) {
    const file = e.target.files[0];
    if (!file) return;
    if (!/^image\/(png|jpe?g|gif|webp)$/.test(file.type)) {
      toast('Please choose a PNG, JPG, GIF or WEBP image', 'error');
      e.target.value = '';
      return;
    }
    if (file.size > MAX_IMAGE_BYTES) {
      toast('Image must be 2 MB or smaller', 'error');
      e.target.value = '';
      return;
    }
    state.imageFile = file;
    state.removeImage = false;
    const reader = new FileReader();
    reader.onload = () => {
      state.imageDataUrl = reader.result;
      field('uploadName').textContent = file.name;
      state.lockedPreview = null;
      renderPreview();
    };
    reader.readAsDataURL(file);
  }

  function clearImage() {
    clearImageState();
    if (state.editingId) state.removeImage = true;
    state.lockedPreview = null;
    renderPreview();
  }

  // ------------------------------------------------------------ init & events
  async function handleSubmit(e) {
    e.preventDefault();
    if (!validateForm()) {
      toast('Please fix the highlighted fields', 'error');
      const first = $('.field.invalid input, .field.invalid textarea');
      if (first) first.focus();
      return;
    }
    const isEdit = state.editingId !== null;
    const btn = field('submitBtn');
    setBusy(btn, true);
    try {
      const body = await api(isEdit ? `${API}/${state.editingId}` : API, {
        method: isEdit ? 'PUT' : 'POST',
        body: buildFormData(),
      });
      toast(body.message || (isEdit ? 'Profile updated' : 'Profile created'));
      const savedId = body.data.id;
      resetForm(true);
      state.currentId = savedId;
      state.lockedPreview = body.data;
      renderPreview();
      await refreshAll();
    } catch (err) {
      serverErrors(err.errors || {});
      if (err.errors && err.errors.skills) toast(err.errors.skills, 'error');
      if (err.errors && err.errors.interests) toast(err.errors.interests, 'error');
      toast(err.message, 'error');
    } finally {
      setBusy(btn, false);
      setFormMode(state.editingId !== null);
    }
  }

  function bindEvents() {
    const form = field('profileForm');

    form.addEventListener('input', e => {
      state.lockedPreview = null;
      if (e.target.id && RULES[e.target.id] && e.target.closest('.field.invalid')) validateField(e.target.id);
      renderPreview();
    });
    form.addEventListener('focusout', e => {
      if (e.target.id && RULES[e.target.id]) validateField(e.target.id);
    });
    form.addEventListener('submit', handleSubmit);

    field('resetBtn').addEventListener('click', () => resetForm());
    field('cancelEdit').addEventListener('click', () => resetForm());
    field('imageFile').addEventListener('change', handleImageChange);
    field('removeImage').addEventListener('click', clearImage);

    setupTagInput('skills');
    setupTagInput('interests');
    field('skillTags').addEventListener('click', e => tagRemove(e, 'skills'));
    field('interestTags').addEventListener('click', e => tagRemove(e, 'interests'));

    field('themePills').addEventListener('click', e => {
      const btn = e.target.closest('[data-theme]');
      if (!btn) return;
      state.theme = btn.dataset.theme;
      state.lockedPreview = null;
      renderPills();
      renderPreview();
    });
    field('templatePills').addEventListener('click', e => {
      const btn = e.target.closest('[data-template]');
      if (!btn) return;
      state.template = Number(btn.dataset.template);
      state.lockedPreview = null;
      renderPills();
      renderPreview();
    });

    let searchTimer;
    field('searchInput').addEventListener('input', e => {
      clearTimeout(searchTimer);
      searchTimer = setTimeout(() => {
        state.search = e.target.value.trim();
        loadProfiles();
      }, 300);
    });
    field('favFilter').addEventListener('click', () => {
      state.favoritesOnly = !state.favoritesOnly;
      field('favFilter').classList.toggle('favorites-on', state.favoritesOnly);
      loadProfiles();
    });

    field('profileGrid').addEventListener('click', e => {
      const item = e.target.closest('.profile-item');
      if (!item) return;
      const id = Number(item.dataset.id);
      const btn = e.target.closest('[data-action]');
      if (!btn) {
        if (e.target.closest('.pi-card')) viewProfile(id);
        return;
      }
      const p = state.profiles.find(x => x.id === id);
      switch (btn.dataset.action) {
        case 'fav': toggleFavorite(id); break;
        case 'edit': startEdit(id); break;
        case 'qr': showQr(id); break;
        case 'download': downloadCard(item.querySelector('.pc-card'), `profilecard-${p ? p.username : id}`); break;
        case 'share': shareProfile(id); break;
        case 'copy': copyText(shareUrl(id)); break;
        case 'delete': askDelete(id); break;
        default: break;
      }
    });

    field('recentList').addEventListener('click', e => {
      const btn = e.target.closest('[data-recent]');
      if (btn) viewProfile(Number(btn.dataset.recent));
    });

    field('dlCard').addEventListener('click', () => {
      const p = state.lockedPreview || previewProfile();
      downloadCard(field('previewStage').querySelector('.pc-card'), `profilecard-${p.username || 'draft'}`);
    });
    field('showQr').addEventListener('click', () => showQr(state.currentId));
    field('copyLink').addEventListener('click', () => state.currentId && copyText(shareUrl(state.currentId)));
    field('shareBtn').addEventListener('click', () => state.currentId && shareProfile(state.currentId));

    field('confirmYes').addEventListener('click', confirmDelete);
    field('confirmNo').addEventListener('click', () => { state.pendingDelete = null; closeModal('confirmModal'); });
    field('qrClose').addEventListener('click', () => closeModal('qrModal'));
    $$('.modal').forEach(m => m.addEventListener('click', e => { if (e.target === m) closeModal(m.id); }));
    document.addEventListener('keydown', e => {
      if (e.key === 'Escape') $$('.modal.open').forEach(m => closeModal(m.id));
    });

    field('menuToggle').addEventListener('click', () => field('mainNav').classList.toggle('open'));
    $$('#mainNav a').forEach(a => a.addEventListener('click', () => field('mainNav').classList.remove('open')));
    field('themeToggle').addEventListener('click', toggleMode);
  }

  function tagRemove(e, key) {
    const btn = e.target.closest('[data-tag]');
    if (!btn) return;
    state[key].splice(Number(btn.dataset.index), 1);
    renderTags(key);
    state.lockedPreview = null;
    renderPreview();
  }

  function applyMode(mode) {
    document.body.classList.toggle('light', mode === 'light');
    field('themeToggle').innerHTML = mode === 'light'
      ? '<i class="fa-solid fa-sun"></i>'
      : '<i class="fa-solid fa-moon"></i>';
  }

  function toggleMode() {
    const next = document.body.classList.contains('light') ? 'dark' : 'light';
    applyMode(next);
    try { localStorage.setItem('profilecraft-mode', next); } catch { /* storage unavailable */ }
  }

  function initMode() {
    let saved = 'dark';
    try { saved = localStorage.getItem('profilecraft-mode') || 'dark'; } catch { /* ignore */ }
    applyMode(saved);
  }

  function initBackground() {
    if (!window.GhostFibers) return;
    window.GhostFibers.mount(field('fibers'), {
      glowColor: '#8b5cf6',
      lineColor: '#dfd1fc',
      secondaryColor: '#6f4ac5',
      gradient: 'depth',
      layers: 3,
      twist: 1.2,
      threads: 72,
      waves: 1,
      volume: 0.7,
      rotation: 18,
      perspective: 0.65,
      depthOfField: 0.85,
      particles: 0.5,
      sparkle: 0.5,
      glow: 0.8,
      vignette: 0.3,
      grain: 0.06,
      speed: 0.5,
      flow: 0.4,
    });
  }

  async function init() {
    initMode();
    initBackground();
    renderPills();
    renderTags('skills');
    renderTags('interests');
    setFormMode(false);
    renderPreview();
    bindEvents();
    await refreshAll();

    const match = location.pathname.match(/^\/p\/(\d+)$/);
    if (match) viewProfile(Number(match[1]));
  }

  document.addEventListener('DOMContentLoaded', init);
})();
